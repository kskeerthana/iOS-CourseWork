//
//  CollegeView.swift
//  EmptyApp
//
//  Created by Keerthana Srinivasan on 10/28/23.
//  Copyright © 2023 rab. All rights reserved.
//

import SwiftUI

class CollegeView: UIView {
    
    var currentActiveView: UIView?
    let manageView = ManageCollegeView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupMenu()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupMenu() {
        let buttonTitles = ["Create College", "Update College", "Delete College", "Search College", "Display Colleges"]
        let buttonActions: [Selector] = [#selector(createButtonTapped), #selector(updateButtonTapped), #selector(deleteButtonTapped), #selector(searchButtonTapped), #selector(displayButtonTapped)]

        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stackView)

        for (index, title) in buttonTitles.enumerated() {
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.addTarget(self, action: buttonActions[index], for: .touchUpInside)
            stackView.addArrangedSubview(button)
        }

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: centerXAnchor),
            stackView.topAnchor.constraint(equalTo: topAnchor, constant: 40),
            stackView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.8)
        ])
    }

    @objc func createButtonTapped() {
        removeCurrentActiveView()
        manageView.configure(for: .create)
        addSubview(manageView)
        currentActiveView = manageView
    }
    
    @objc func updateButtonTapped() {
        removeCurrentActiveView()
        manageView.configure(for: .create)
        addSubview(manageView)
        currentActiveView = manageView
    }
    
    @objc func deleteButtonTapped() {
        removeCurrentActiveView()
        manageView.configure(for: .create)
        addSubview(manageView)
        currentActiveView = manageView
    }
    
    @objc func searchButtonTapped() {
        removeCurrentActiveView()
        manageView.configure(for: .create)
        addSubview(manageView)
        currentActiveView = manageView
    }
    
    @objc func displayButtonTapped() {
        removeCurrentActiveView()
        manageView.configure(for: .create)
        addSubview(manageView)
        currentActiveView = manageView
    }

    func removeCurrentActiveView() {
            currentActiveView?.removeFromSuperview()
            currentActiveView = nil
        }
    
}
