import UIKit

class MainView: UIView {

    var menuButtons: [UIButton] = []
    var stackView: UIStackView!
    var currentSubview: UIView?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupUI() {
        stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.distribution = .fill
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: trailingAnchor),
            stackView.topAnchor.constraint(equalTo: topAnchor),
            stackView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])

        let mainMenuView = UIView()
        let titles = ["Manage Programs", "Manage Courses", "Manage Course Categories", "Manage Colleges", "Exit"]
        for (index, title) in titles.enumerated() {
            let button = createButton(title: title, action: #selector(menuButtonTapped(sender:)))
            button.tag = index + 1
            menuButtons.append(button)
            mainMenuView.addSubview(button)
        }
        
        setupConstraints(for: mainMenuView)
        stackView.addArrangedSubview(mainMenuView)
    }

    func createButton(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }

    @objc func menuButtonTapped(sender: UIButton) {
        switch sender.tag {
        case 1:
//            let manageCollegeView = ManageCollegeView(frame: bounds)
            let CollegeView = CollegeView(frame: bounds)
            stackView.addArrangedSubview(CollegeView)
            currentSubview = CollegeView
            stackView.arrangedSubviews.first?.isHidden = true
            // Handle other pages here...
        case 4:
            let CollegeView = CollegeView(frame: bounds)
            stackView.addArrangedSubview(CollegeView)
            currentSubview = CollegeView
            stackView.arrangedSubviews.first?.isHidden = true // Hide main menu
        default:
            break
        }
    }

    func setupConstraints(for view: UIView) {
        for (index, button) in menuButtons.enumerated() {
            button.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                button.topAnchor.constraint(equalTo: view.topAnchor, constant: 50 + CGFloat(index) * 60)
            ])
        }
    }

    // Define the functions managePrograms, manageCourses, manageCourseCategories, and manageColleges
    // ...
}

